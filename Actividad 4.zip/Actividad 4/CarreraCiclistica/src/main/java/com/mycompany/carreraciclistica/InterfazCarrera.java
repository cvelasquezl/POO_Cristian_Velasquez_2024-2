package com.mycompany.carreraciclistica;

import javax.swing.*;
import java.awt.*;
import java.io.ByteArrayOutputStream;
import java.io.PrintStream;
import java.util.ArrayList;
import java.util.List;

public class InterfazCarrera extends JFrame {

    private JComboBox<String> comboBoxEquipos;
    private JTextArea textAreaDetalles;
    private List<Equipo> equipos;

    public InterfazCarrera() {
        // Inicializar lista de equipos
        equipos = new ArrayList<>();

        // Crear equipos y agregar ciclistas
        Equipo equipo1 = new Equipo("Ineos Grenadiers", "Reino Unido");
        Velocista velocista1 = new Velocista(123979, "Geraint Thomas", 320, 25);
        Escalador escalador1 = new Escalador(123980, "Egan Bernal", 25, 10);
        Contrarrelojista contrarrelojista1 = new Contrarrelojista(123981, "Jonathan Castroviejo", 120);
        equipo1.añadirCiclista(velocista1);
        equipo1.añadirCiclista(escalador1);
        equipo1.añadirCiclista(contrarrelojista1);
        
        velocista1.setTiempoAcumulado(365);
        escalador1.setTiempoAcumulado(385);
        contrarrelojista1.setTiempoAcumulado(370);
        
        equipo1.calcularTotalTiempo();
        equipos.add(equipo1);

        // Equipo 2
        Equipo equipo2 = new Equipo("Movistar Team", "España");
        Velocista velocista2 = new Velocista(123982, "Mikel Landa", 315, 28);
        Escalador escalador2 = new Escalador(123983, "Enric Mas", 26, 12);
        Contrarrelojista contrarrelojista2 = new Contrarrelojista(123984, "Marcel Kittel", 125);

        equipo2.añadirCiclista(velocista2);
        equipo2.añadirCiclista(escalador2);
        equipo2.añadirCiclista(contrarrelojista2);

        velocista2.setTiempoAcumulado(355);
        escalador2.setTiempoAcumulado(375);
        contrarrelojista2.setTiempoAcumulado(365);
        
        equipo2.calcularTotalTiempo();
        equipos.add(equipo2);

        // Equipo 3
        Equipo equipo3 = new Equipo("Jumbo-Visma", "Países Bajos");
        Velocista velocista3 = new Velocista(123985, "Tom Dumoulin", 330, 26);
        Escalador escalador3 = new Escalador(123986, "Primož Roglič", 27, 15);
        Contrarrelojista contrarrelojista3 = new Contrarrelojista(123987, "Wout Van Aert", 130);

        equipo3.añadirCiclista(velocista3);
        equipo3.añadirCiclista(escalador3);
        equipo3.añadirCiclista(contrarrelojista3);

        velocista3.setTiempoAcumulado(340);
        escalador3.setTiempoAcumulado(360);
        contrarrelojista3.setTiempoAcumulado(375);

        equipo3.calcularTotalTiempo();
        equipos.add(equipo3);

        // Equipo 4
        Equipo equipo4 = new Equipo("Bora-Hansgrohe", "Alemania");
        Velocista velocista4 = new Velocista(123988, "Peter Sagan", 325, 29);
        Escalador escalador4 = new Escalador(123989, "Wilco Kelderman", 27, 13);
        Contrarrelojista contrarrelojista4 = new Contrarrelojista(123990, "Rafal Majka", 140);

        equipo4.añadirCiclista(velocista4);
        equipo4.añadirCiclista(escalador4);
        equipo4.añadirCiclista(contrarrelojista4);

        velocista4.setTiempoAcumulado(375);
        escalador4.setTiempoAcumulado(395);
        contrarrelojista4.setTiempoAcumulado(380);

        equipo4.calcularTotalTiempo();
        equipos.add(equipo4);

        // Equipo 5
        Equipo equipo5 = new Equipo("Astana Pro Team", "Kazajistán");
        Velocista velocista5 = new Velocista(123991, "Alexey Lutsenko", 310, 26);
        Escalador escalador5 = new Escalador(123992, "Vincenzo Nibali", 35, 14);
        Contrarrelojista contrarrelojista5 = new Contrarrelojista(123993, "Jakob Fuglsang", 150);

        equipo5.añadirCiclista(velocista5);
        equipo5.añadirCiclista(escalador5);
        equipo5.añadirCiclista(contrarrelojista5);

        velocista5.setTiempoAcumulado(350);
        escalador5.setTiempoAcumulado(370);
        contrarrelojista5.setTiempoAcumulado(395);
        
        equipo5.calcularTotalTiempo();
        equipos.add(equipo5);
        
        // Equipo 6 (Equipo de Nairo Quintana)
        Equipo equipo6 = new Equipo("Arkea-Samsic", "Francia");
        Velocista velocista6 = new Velocista(123994, "Nairo Quintana", 330, 30);
        Escalador escalador6 = new Escalador(123995, "Warren Barguil", 32, 13);
        Contrarrelojista contrarrelojista6 = new Contrarrelojista(123996, "Kévin Ledanois", 140);

        equipo6.añadirCiclista(velocista6);
        equipo6.añadirCiclista(escalador6);
        equipo6.añadirCiclista(contrarrelojista6);

        velocista6.setTiempoAcumulado(385);
        escalador6.setTiempoAcumulado(375);
        contrarrelojista6.setTiempoAcumulado(400);

        equipo6.calcularTotalTiempo();
        equipos.add(equipo6);
        
        // Equipo 7 (Equipo de Rigoberto Urán)
        Equipo equipo7 = new Equipo("EF Education-Nippo", "Estados Unidos");
        Velocista velocista7 = new Velocista(123997, "Rigoberto Urán", 315, 33);
        Escalador escalador7 = new Escalador(123998, "Hugh Carthy", 26, 14);
        Contrarrelojista contrarrelojista7 = new Contrarrelojista(123999, "Tadej Pogačar", 120);

        equipo7.añadirCiclista(velocista7);
        equipo7.añadirCiclista(escalador7);
        equipo7.añadirCiclista(contrarrelojista7);

        velocista7.setTiempoAcumulado(360);
        escalador7.setTiempoAcumulado(380);
        contrarrelojista7.setTiempoAcumulado(395);
        
        equipo7.calcularTotalTiempo();
        equipos.add(equipo7);

        // Configuración del JFrame
        setTitle("Seleccionar Equipo");
        setSize(600, 400);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLayout(new BorderLayout());

        // Crear el JComboBox con los nombres de los equipos
        comboBoxEquipos = new JComboBox<>();
        for (Equipo equipo : equipos) {
            comboBoxEquipos.addItem(equipo.getNombre());
        }

        // Crear el JTextArea para mostrar los detalles del equipo
        textAreaDetalles = new JTextArea();
        textAreaDetalles.setEditable(false);
        textAreaDetalles.setLineWrap(true);
        textAreaDetalles.setWrapStyleWord(true);

        // Listener para cuando se selecciona un equipo
        comboBoxEquipos.addActionListener(e -> mostrarDatosEquipo());

        // Agregar los componentes al JFrame
        add(comboBoxEquipos, BorderLayout.NORTH);
        add(new JScrollPane(textAreaDetalles), BorderLayout.CENTER);

        // Mostrar la ventana
        setVisible(true);
    }

    // Método para mostrar los datos del equipo seleccionado
    private void mostrarDatosEquipo() {
        String nombreEquipo = (String) comboBoxEquipos.getSelectedItem();
        Equipo equipoSeleccionado = obtenerEquipoPorNombre(nombreEquipo);

        if (equipoSeleccionado != null) {
            // Redirigir la salida de imprimir() y listarEquipo() a un ByteArrayOutputStream
            ByteArrayOutputStream baos = new ByteArrayOutputStream();
            PrintStream ps = new PrintStream(baos);
            PrintStream originalOut = System.out;
            System.setOut(ps);

            // Llamar a los métodos imprimir() y listarEquipo()
            equipoSeleccionado.calcularTotalTiempo();
            equipoSeleccionado.imprimir();
            equipoSeleccionado.listarEquipo();

            // Restaurar la salida estándar
            System.setOut(originalOut);

            // Mostrar el contenido capturado en el JTextArea
            textAreaDetalles.setText(baos.toString());
        }
    }

    // Método para obtener el equipo por su nombre
    private Equipo obtenerEquipoPorNombre(String nombre) {
        for (Equipo equipo : equipos) {
            if (equipo.getNombre().equals(nombre)) {
                return equipo;
            }
        }
        return null;
    }

    // Método main para ejecutar la interfaz
    public static void main(String[] args) {
        new InterfazCarrera();
    }
}


