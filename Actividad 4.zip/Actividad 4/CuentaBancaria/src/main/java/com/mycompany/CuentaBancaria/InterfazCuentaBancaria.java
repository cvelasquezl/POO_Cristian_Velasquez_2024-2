package com.mycompany.CuentaBancaria;

import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class InterfazCuentaBancaria extends JFrame {
    private Cuenta cuenta;
    private JTextField saldoInicialField, tasaField, depositField, withdrawField;
    private JTextArea outputArea;
    private JButton consignarButton, retirarButton, extractoButton, createButton;
    private JComboBox<String> accountTypeComboBox;

    public InterfazCuentaBancaria() {
        setTitle("Gestión de Cuentas");
        setSize(400, 450);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLayout(null);

        // Create components
        JLabel saldoInicialLabel = new JLabel("Saldo Inicial:");
        saldoInicialLabel.setBounds(20, 20, 100, 25);
        add(saldoInicialLabel);

        saldoInicialField = new JTextField();
        saldoInicialField.setBounds(120, 20, 150, 25);
        add(saldoInicialField);

        JLabel tasaLabel = new JLabel("Tasa de Interés  (%):");
        tasaLabel.setBounds(20, 60, 150, 25);
        add(tasaLabel);

        tasaField = new JTextField();
        tasaField.setBounds(150, 60, 70, 25);
        add(tasaField);

        JLabel accountTypeLabel = new JLabel("Tipo de Cuenta:");
        accountTypeLabel.setBounds(20, 100, 100, 25);
        add(accountTypeLabel);

        // Combo box for selecting account type
        String[] accountTypes = {"Cuenta de Ahorros", "Cuenta Corriente"};
        accountTypeComboBox = new JComboBox<>(accountTypes);
        accountTypeComboBox.setBounds(120, 100, 150, 25);
        add(accountTypeComboBox);

        createButton = new JButton("Crear Cuenta");
        createButton.setBounds(20, 140, 150, 30);
        add(createButton);

        consignarButton = new JButton("Consignar");
        consignarButton.setBounds(20, 180, 100, 30);
        add(consignarButton);

        depositField = new JTextField();
        depositField.setBounds(130, 180, 150, 25);
        add(depositField);

        retirarButton = new JButton("Retirar");
        retirarButton.setBounds(20, 220, 100, 30);
        add(retirarButton);

        withdrawField = new JTextField();
        withdrawField.setBounds(130, 220, 150, 25);
        add(withdrawField);

        extractoButton = new JButton("Extracto Mensual");
        extractoButton.setBounds(20, 260, 150, 30);
        add(extractoButton);

        outputArea = new JTextArea();
        outputArea.setBounds(20, 300, 350, 100);
        outputArea.setEditable(false);
        add(outputArea);

        // Event listeners
        createButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                try {
                    float saldo = Float.parseFloat(saldoInicialField.getText());
                    float tasa = Float.parseFloat(tasaField.getText());
                    String selectedAccountType = (String) accountTypeComboBox.getSelectedItem();

                    if ("Cuenta de Ahorros".equals(selectedAccountType)) {
                        cuenta = new CuentaAhorros(saldo, tasa);
                        outputArea.setText("Cuenta de Ahorros creada con saldo inicial de $" + saldo);
                    } else if ("Cuenta Corriente".equals(selectedAccountType)) {
                        cuenta = new CuentaCorriente(saldo, tasa);
                        outputArea.setText("Cuenta Corriente creada con saldo inicial de $" + saldo);
                    }
                } catch (NumberFormatException ex) {
                    outputArea.setText("Por favor, ingrese valores válidos.");
                }
            }
        });

        consignarButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                try {
                    if (cuenta != null) {
                        float deposit = Float.parseFloat(depositField.getText());
                        cuenta.consignar(deposit);
                        outputArea.setText("Deposito realizado: $" + deposit);
                    } else {
                        outputArea.setText("Primero cree una cuenta.");
                    }
                } catch (NumberFormatException ex) {
                    outputArea.setText("Por favor, ingrese valores válidos.");
                }
            }
        });

        retirarButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                try {
                    if (cuenta != null) {
                        float withdraw = Float.parseFloat(withdrawField.getText());
                        cuenta.retirar(withdraw);
                        outputArea.setText("Retiro realizado: $" + withdraw);
                    } else {
                        outputArea.setText("Primero cree una cuenta.");
                    }
                } catch (NumberFormatException ex) {
                    outputArea.setText("Por favor, ingrese valores válidos.");
                }
            }
        });

        extractoButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                if (cuenta != null) {
                    cuenta.extractoMensual();
                    outputArea.setText("Extracto generado. Saldo: $" + cuenta.saldo);
                } else {
                    outputArea.setText("Primero cree una cuenta.");
                }
            }
        });
    }

    public static void main(String[] args) {
        // Run the GUI
        SwingUtilities.invokeLater(new Runnable() {
            @Override
            public void run() {
                new InterfazCuentaBancaria().setVisible(true);
            }
        });
    }
}
