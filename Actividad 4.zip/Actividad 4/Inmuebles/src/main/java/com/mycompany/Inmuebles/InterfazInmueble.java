package com.mycompany.Inmuebles;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

public class InterfazInmueble extends JFrame {
    private JComboBox<String> comboBoxInmuebles;
    private JPanel panelCampos;
    private JButton btnCalcular;
    private JLabel lblPrecioVenta;
    private JTextField txtIdentificador, txtArea, txtDireccion, txtHabitaciones, txtBanos, txtPisos, txtValorAdmin, txtDistancia, txtAltitud, txtCentroComercial, txtValor;

    public InterfazInmueble() {
        setTitle("Gestión de Inmuebles");
        setSize(600, 400);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLayout(new BorderLayout());

        // Crear componentes
        comboBoxInmuebles = new JComboBox<>(new String[]{
            "Seleccionar tipo", "Casa Rural", "Casa Conjunto Cerrado", "Casa Independiente", "Apartaestudio",
            "Apartamento Familiar", "Local Comercial", "Oficina"
        });

        panelCampos = new JPanel();
        panelCampos.setLayout(new GridLayout(0, 2));

        btnCalcular = new JButton("Calcular Precio Venta");
        lblPrecioVenta = new JLabel("Precio de venta: $0");

        // Añadir componentes a la interfaz
        JPanel panelTop = new JPanel();
        panelTop.add(comboBoxInmuebles);
        add(panelTop, BorderLayout.NORTH);

        add(panelCampos, BorderLayout.CENTER);

        JPanel panelBottom = new JPanel();
        panelBottom.add(btnCalcular);
        panelBottom.add(lblPrecioVenta);
        add(panelBottom, BorderLayout.SOUTH);

        // Agregar eventos
        comboBoxInmuebles.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                mostrarCampos();
            }
        });

        btnCalcular.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                calcularPrecioVenta();
            }
        });

        mostrarCampos();
    }

    private void mostrarCampos() {
        panelCampos.removeAll();
        String tipoInmueble = (String) comboBoxInmuebles.getSelectedItem();

        if (tipoInmueble == null || tipoInmueble.equals("Seleccionar tipo")) {
            return;
        }

        // Campos comunes
        panelCampos.add(new JLabel("Identificador inmobiliario:"));
        txtIdentificador = new JTextField();
        panelCampos.add(txtIdentificador);

        panelCampos.add(new JLabel("Área (m2):"));
        txtArea = new JTextField();
        panelCampos.add(txtArea);

        panelCampos.add(new JLabel("Dirección:"));
        txtDireccion = new JTextField();
        panelCampos.add(txtDireccion);

        // Mostrar campos específicos por tipo de inmueble
        switch (tipoInmueble) {
            case "Casa Rural":
                panelCampos.add(new JLabel("Número de habitaciones:"));
                txtHabitaciones = new JTextField();
                panelCampos.add(txtHabitaciones);

                panelCampos.add(new JLabel("Número de baños:"));
                txtBanos = new JTextField();
                panelCampos.add(txtBanos);

                panelCampos.add(new JLabel("Número de pisos:"));
                txtPisos = new JTextField();
                panelCampos.add(txtPisos);

                panelCampos.add(new JLabel("Distancia a la cabecera municipal (km):"));
                txtDistancia = new JTextField();
                panelCampos.add(txtDistancia);

                panelCampos.add(new JLabel("Altitud sobre el nivel del mar (m):"));
                txtAltitud = new JTextField();
                panelCampos.add(txtAltitud);
                break;

            case "Casa Conjunto Cerrado":
                panelCampos.add(new JLabel("Número de habitaciones:"));
                txtHabitaciones = new JTextField();
                panelCampos.add(txtHabitaciones);

                panelCampos.add(new JLabel("Número de baños:"));
                txtBanos = new JTextField();
                panelCampos.add(txtBanos);

                panelCampos.add(new JLabel("Número de pisos:"));
                txtPisos = new JTextField();
                panelCampos.add(txtPisos);

                panelCampos.add(new JLabel("Valor de administración:"));
                txtValorAdmin = new JTextField();
                panelCampos.add(txtValorAdmin);

                panelCampos.add(new JLabel("Tiene piscina (true/false):"));
                txtDistancia = new JTextField();
                panelCampos.add(txtDistancia);

                panelCampos.add(new JLabel("Tiene campos deportivos (true/false):"));
                txtAltitud = new JTextField();
                panelCampos.add(txtAltitud);
                break;

            case "Casa Independiente":
                panelCampos.add(new JLabel("Número de habitaciones:"));
                txtHabitaciones = new JTextField();
                panelCampos.add(txtHabitaciones);

                panelCampos.add(new JLabel("Número de baños:"));
                txtBanos = new JTextField();
                panelCampos.add(txtBanos);

                panelCampos.add(new JLabel("Número de pisos:"));
                txtPisos = new JTextField();
                panelCampos.add(txtPisos);
                break;

            case "Apartamento Familiar":
                panelCampos.add(new JLabel("Número de habitaciones:"));
                txtHabitaciones = new JTextField();
                panelCampos.add(txtHabitaciones);

                panelCampos.add(new JLabel("Número de baños:"));
                txtBanos = new JTextField();
                panelCampos.add(txtBanos);

                panelCampos.add(new JLabel("Valor de administración:"));
                txtValorAdmin = new JTextField();
                panelCampos.add(txtValorAdmin);
                break;


            case "Local Comercial":
                panelCampos.add(new JLabel("Área (m2):"));
                txtArea = new JTextField();
                panelCampos.add(txtArea);

                panelCampos.add(new JLabel("Dirección:"));
                txtDireccion = new JTextField();
                panelCampos.add(txtDireccion);

                panelCampos.add(new JLabel("Tipo de local (INTERNO, CALLE):"));
                txtDistancia = new JTextField();
                panelCampos.add(txtDistancia);

                panelCampos.add(new JLabel("Centro comercial:"));
                txtCentroComercial = new JTextField();
                panelCampos.add(txtCentroComercial);
                break;

            case "Oficina":
                panelCampos.add(new JLabel("Área (m2):"));
                txtArea = new JTextField();
                panelCampos.add(txtArea);

                panelCampos.add(new JLabel("Dirección:"));
                txtDireccion = new JTextField();
                panelCampos.add(txtDireccion);

                panelCampos.add(new JLabel("Tipo de local (INTERNO, CALLE):"));
                txtDistancia = new JTextField();
                panelCampos.add(txtDistancia);

                panelCampos.add(new JLabel("Es oficina gubernamental (true/false):"));
                txtAltitud = new JTextField();
                panelCampos.add(txtAltitud);
                break;
        }

        revalidate();
        repaint();
    }

    private void calcularPrecioVenta() {
        String tipoInmueble = (String) comboBoxInmuebles.getSelectedItem();
        if (tipoInmueble == null || tipoInmueble.equals("Seleccionar tipo")) {
            return;
        }

        double valorArea = 0;

        // Establecer el valor por metro cuadrado según el tipo de inmueble
        switch (tipoInmueble) {
            case "Casa Rural":
                valorArea = CasaRural.valorArea;
                break;
            case "Casa Conjunto Cerrado":
                valorArea = CasaConjuntoCerrado.valorArea;
                break;
            case "Casa Independiente":
                valorArea = CasaIndependiente.valorArea;
                break;
            case "Apartaestudio":
                valorArea = Apartaestudio.valorArea;
                break;
            case "Apartamento Familiar":
                valorArea = ApartamentoFamiliar.valorArea;
                break;
            case "Local Comercial":
                valorArea = LocalComercial.valorArea;
                break;
            case "Oficina":
                valorArea = Oficina.valorArea;
                break;
        }

        // Calcular precio de venta
        int area = Integer.parseInt(txtArea.getText());
        double precioVenta = area * valorArea;
        lblPrecioVenta.setText("Precio de venta: $" + precioVenta);
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(new Runnable() {
            public void run() {
                new InterfazInmueble().setVisible(true);
            }
        });
    }
}
