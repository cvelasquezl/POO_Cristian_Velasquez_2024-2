package com.mycompany.datospersona;

public class Persona {
    String nombre;
    String apellidos;
    String teléfono;
    String dirección;

    public Persona(String nombre, String apellidos, String teléfono, String dirección) {
        this.nombre = nombre;
        this.apellidos = apellidos;
        this.teléfono = teléfono;
        this.dirección = dirección;
    }
}

