package com.mycompany.datospersona;

public class Principal {
    public static void main(String[] args) {
        VentanaPrincipal miVentanaPrincipal;
        miVentanaPrincipal = new VentanaPrincipal();
        miVentanaPrincipal.setVisible(true);
    }
}
