package com.mycompany.animales;

public abstract class Felino extends Animal {
    // Puede contener métodos específicos para los felinos, si es necesario
}
