package com.mycompany.animales;

public class Perro extends Canido {
    public String getSonido() {
        return "Ladrido";
    }
    public String getAlimentos() {
        return "Carnivoro";
    }
    public String getHabitat() {
        return "Domestico";
    }
    public String getnombreCientifico() {
        return "Canis lupus familiaris";
    }
}

