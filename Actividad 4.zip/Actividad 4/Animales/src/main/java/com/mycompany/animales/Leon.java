package com.mycompany.animales;

public class Leon extends Felino {
    public String getSonido() {
        return "Rugido";
    }
    public String getAlimentos() {
        return "Carnivoro";
    }
    public String getHabitat() {
        return "Praderas";
    }
    public String getnombreCientifico() {
        return "Panthera Leo";
    }
}

