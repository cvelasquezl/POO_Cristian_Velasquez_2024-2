package com.mycompany.animales;

public class Lobo extends Canido {
    public String getSonido() {
        return "Aullido";
    }
    public String getAlimentos() {
        return "Carnivoro";
    }
    public String getHabitat() {
        return "Bosque";
    }
    public String getnombreCientifico() {
        return "Canis Lupus";
    }
}
