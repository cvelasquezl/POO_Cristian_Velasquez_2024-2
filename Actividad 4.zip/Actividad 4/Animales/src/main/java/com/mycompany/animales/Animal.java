package com.mycompany.animales;

public abstract class Animal {
    protected String sonido;
    protected String Habitat;
    protected String Alimentos;
    protected String nombreCintifico;

    public abstract String getSonido();
    public abstract String getHabitat();
    public abstract String getAlimentos();
    public abstract String getnombreCientifico();
}
