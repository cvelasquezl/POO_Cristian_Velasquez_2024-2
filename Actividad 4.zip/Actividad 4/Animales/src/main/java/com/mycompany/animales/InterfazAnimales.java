package com.mycompany.animales;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

public class InterfazAnimales extends JFrame {
    private JComboBox<String> comboBoxAnimales;
    private JPanel panelAtributos;
    private JTextArea textAreaAtributos;
    
    public InterfazAnimales() {
        setTitle("Seleccionar Animal");
        setSize(400, 300);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLayout(new BorderLayout());

        // Crear componentes
        comboBoxAnimales = new JComboBox<>(new String[]{
            "Seleccionar Animal", "Gato", "Perro", "Lobo", "León"
        });

        panelAtributos = new JPanel();
        panelAtributos.setLayout(new BorderLayout());

        textAreaAtributos = new JTextArea();
        textAreaAtributos.setEditable(false);
        textAreaAtributos.setFont(new Font("Arial", Font.PLAIN, 14));
        textAreaAtributos.setBackground(Color.LIGHT_GRAY);
        textAreaAtributos.setLineWrap(true);
        textAreaAtributos.setWrapStyleWord(true);
        textAreaAtributos.setMargin(new Insets(10, 10, 10, 10));
        
        JScrollPane scrollPane = new JScrollPane(textAreaAtributos);
        
        // Añadir componentes a la interfaz
        JPanel panelTop = new JPanel();
        panelTop.add(comboBoxAnimales);
        add(panelTop, BorderLayout.NORTH);

        add(scrollPane, BorderLayout.CENTER);

        // Agregar eventos
        comboBoxAnimales.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                mostrarAtributos();
            }
        });

        mostrarAtributos();
    }

    private void mostrarAtributos() {
        String tipoAnimal = (String) comboBoxAnimales.getSelectedItem();

        if (tipoAnimal == null || tipoAnimal.equals("Seleccionar Animal")) {
            return;
        }

        Animal animal = null;

        // Crear el animal correspondiente según la selección
        switch (tipoAnimal) {
            case "Gato":
                animal = new Gato();
                break;
            case "Perro":
                animal = new Perro();
                break;
            case "Lobo":
                animal = new Lobo();
                break;
            case "León":
                animal = new Leon();
                break;
        }

        // Mostrar los atributos del animal seleccionado en un formato organizado
        if (animal != null) {
            String atributos = "Sonido: " + animal.getSonido() + "\n" +
                               "Hábitat: " + animal.getHabitat() + "\n" +
                               "Alimentos: " + animal.getAlimentos() + "\n" +
                               "Nombre Científico: " + animal.getnombreCientifico();
            textAreaAtributos.setText(atributos);
        }
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(new Runnable() {
            public void run() {
                new InterfazAnimales().setVisible(true);
            }
        });
    }
}

