package com.mycompany.animales;

public class Gato extends Felino {
    public String getSonido() {
        return "Maullido";
    }
    public String getAlimentos() {
        return "Ratones";
    }
    public String getHabitat() {
        return "Domestico";
    }
    public String getnombreCientifico() {
        return "Felis silvestris catus";
    }
}
