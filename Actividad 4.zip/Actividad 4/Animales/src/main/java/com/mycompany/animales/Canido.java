package com.mycompany.animales;

public abstract class Canido extends Animal {
    // Puede contener métodos específicos para los canidos, si es necesario
}