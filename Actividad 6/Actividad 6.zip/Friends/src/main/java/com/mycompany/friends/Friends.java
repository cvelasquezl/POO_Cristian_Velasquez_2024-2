package com.mycompany.friends;


public class Friends {

    public static void main(String[] args) {
        MainForm frm = new MainForm();
        frm.setVisible(true);
    }
}
